Tutorials
=========

Here, you will find tutorials explaining how to utilize the different functionalities of NeSy4PPM.
All tutorials can be downloaded and run from our
`Github. <https://github.com/JamilaOUKHARIJANE/NeSy4PPM/tree/master/docs/source/tutorials>`_ The tutorials use the `Helpdesk log <https://data.4tu.nl/articles/dataset/Dataset_belonging_to_the_help_desk_log_of_an_Italian_Company/12675977>`_ as a running example.
List of available tutorials:

.. toctree::
   :maxdepth: 2
   :caption: Tutorials

   tutorials/Suffix_Prediction_tutorial
